package shop.notification;

public interface NotificationChannel{
    public String channelName();

    public boolean send(CustomerContact contact, String message); 
}
