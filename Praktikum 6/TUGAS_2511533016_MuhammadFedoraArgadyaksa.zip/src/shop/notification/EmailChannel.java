package shop.notification;

public class EmailChannel extends AbstractChannel {


    public EmailChannel() {
    }   

    @Override 
    public String channelName() {
        return "Email";
    }
    
    @Override 
    protected String resolveTarget(CustomerContact contact) {
        String email = contact.getEmail();
        return email.contains("@") ? email : null;
    }
 
    @Override 
    protected String prepareMessage(String message) {
        return message;
    }

}
