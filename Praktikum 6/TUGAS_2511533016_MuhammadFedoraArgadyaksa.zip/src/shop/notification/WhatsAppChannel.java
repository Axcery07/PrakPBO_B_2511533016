package shop.notification;

public class WhatsAppChannel extends AbstractChannel {

    public WhatsAppChannel() {
    }

    @Override
    public String channelName() {
        return "WA";
    }

    // tujuan = telepon berawalan 08 atau +62 dengan panjang minimal 10
    @Override
    public String resolveTarget(CustomerContact contact) {
        String phone = contact.getPhone();
        boolean prefixOk = phone.startsWith("08") || phone.startsWith("+62");
        return (prefixOk && phone.length() >= 10) ? phone : null;
    }

    @Override
    public String prepareMessage(String message) {
        return "[Toko UMKM] " + message;
    }
}