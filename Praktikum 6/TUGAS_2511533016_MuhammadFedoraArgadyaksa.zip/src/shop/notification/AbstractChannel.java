package shop.notification;

public abstract class AbstractChannel implements NotificationChannel {
   private int sentCount = 0;
   private String lastDelivered = null;

   @Override
    public final boolean send(CustomerContact contact, String message) {
        if (contact == null || message == null || message.trim().isEmpty()) {
            return false;
        }

        String target = resolveTarget(contact);
        if (target == null || target.isEmpty()) {
            return false;
        }

        String prepared = prepareMessage(message);

        System.out.println("[" + channelName() + "] ke " + target + ": " + prepared);

        sentCount++;
        lastDelivered = prepared;
        return true;
    }

    protected abstract String resolveTarget(CustomerContact contact);
 
    protected abstract String prepareMessage(String message);
 
    public int getSentCount() {
        return sentCount;
    }

    public String getLastDelivered() {
        return lastDelivered;
    }
}
