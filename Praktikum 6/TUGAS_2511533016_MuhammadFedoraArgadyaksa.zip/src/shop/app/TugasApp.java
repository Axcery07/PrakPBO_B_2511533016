package shop.app;

import java.util.Arrays;
import java.util.List;
import shop.StudentInfo;
import shop.model.PhysicalProduct;
import shop.model.Product;
import shop.notification.*;
import shop.payment.*;
import shop.service.CheckoutService;
import shop.shipping.ExpressShipping;
import shop.shipping.ShippingService;

public class TugasApp {

    public static void main(String[] args) {
        System.out.println("Tugas oleh Muhammad Fedora Argadyaksa (2511533016)");
        System.out.println();

        System.out.println("== T1: Total dengan biaya admin (Ekspres) ==");

        List<Product> items = Arrays.asList(
                new PhysicalProduct("P-001", "Kopi Gayo 1kg", 120000, 1000),
                new PhysicalProduct("P-002", "Kain Songket", 130000, 500)
        );
        ShippingService express = new ExpressShipping();
        CheckoutService checkout = new CheckoutService();

        EWalletPayment ewallet = new EWalletPayment("DompetKu", 1_000_000);
        BankTransferPayment transfer = new BankTransferPayment("Nagari");
        CreditCardPayment card = new CreditCardPayment("Siti Rahma", 5_000_000);

        PaymentMethod[] methods = { ewallet, transfer, card };
        for (PaymentMethod pm : methods) {
            long subtotal = checkout.total(items, express);
            long grand = checkout.grandTotal(items, express, pm);
            System.out.println(pm.getName() + " : Rp" + grand + " (admin Rp" + (grand - subtotal) + ")");
        }

        System.out.println();
        System.out.println("Kebijakan kartu kredit : " + card.policy());
        System.out.println("Kebijakan e-wallet     : " + ewallet.policy());
        System.out.println();

        // ===== T2: notifikasi status pesanan =====
        System.out.println("== T2: Notifikasi status pesanan ==");

        NotificationService service = new NotificationService();
        service.register(new EmailChannel());
        service.register(new SmsChannel(StudentInfo.SMS_MAX_LENGTH));
        service.register(new WhatsAppChannel());
        service.register(new NotificationChannel() {
            @Override
            public String channelName() {
                return "LOG";
            }

            @Override
            public boolean send(CustomerContact contact, String message) {
                System.out.println("[LOG] " + contact.getName() + ": " + message);
                return true;
            }
        });

        String message = "Pesanan ORD-0001 sudah dikirim dengan kurir Ekspres. "
                + "Nomor resi akan muncul di aplikasi dalam 1x24 jam. "
                + "Terima kasih telah berbelanja produk UMKM Sumatera Barat di toko kami! "
                + "Jika ada kendala, silakan hubungi admin toko melalui kontak resmi kami.";

        CustomerContact siti = new CustomerContact("Siti Rahma", "siti@example.com", "081234567890");
        CustomerContact budi = new CustomerContact("Budi", null, "+6281298765432");

        System.out.println("Terkirim ke Siti lewat " + service.broadcast(siti, message) + " kanal");
        System.out.println("Terkirim ke Budi lewat " + service.broadcast(budi, message) + " kanal");
    }
}