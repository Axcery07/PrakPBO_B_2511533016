package shop.model;

import shop.discount.Discountable;

public class DigitalProduct extends Product implements Discountable {
    private static final int DISCOUNT_PERCENT = 10;
    public String downloadUrl;

    public DigitalProduct(String sku, String name, long price, String downloadUrl) {
        super(sku, name, price);
        this.downloadUrl = downloadUrl;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    @Override
    public String category() {
        return "Digital";
    }

    @Override
    public int discountPercent() {
        return DISCOUNT_PERCENT;
    }

    @Override
    public long getFinalPrice() {
        return applyDiscount(super.getPrice());
    }
}
